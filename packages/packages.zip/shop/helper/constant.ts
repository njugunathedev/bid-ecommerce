/************ CONSTANTS ***********/
export const CURRENCY = 'KSH ';
